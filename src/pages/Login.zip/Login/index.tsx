import React, { useState } from "react";
import {
  Button,
  ButtonContainer,
  ContainerImputs,
  EraseSpace,
  EyeSpace,
  IconSpace,
  InputContainer,
  InputLogin,
  LoginContainer,
  Logo,
  TextCadastro,
  TextLogin,
  TextOuuuu,
  TextSenha,
  TwoInput,
} from "./styles";

import { api } from "../../services";
import { Image, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";

const FcLogo = require("../../assets/fc.png");

const LoginScreen = () => {
  // const LockImage = require("../../assets/lock.png");
  const [isCorrectLogin, setIsCorrectLogin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const validEmail = /[a-zA-Z0-9._]+@[a-z0-9]+\.[a-z.]{2,}$/;
  const [emailValue, setEmailValue] = useState("");
  const [senhaValue, setSenhaValue] = useState("");
  const navigation = useNavigation();

  function UserLogin(formEmail: string, formSenha: string) {
    setIsLoading(true);
    const email = formEmail;
    const senha = formSenha;
    api
      .post("/Login", { email, senha })
      .then((response) => {
        localStorage.setItem("userData", JSON.stringify(response.data));
        navigation.navigate("Home" as never);
      })
      .catch(() => {
        setIsCorrectLogin(true);
      })
      .finally(() => setIsLoading(false));
  }

  const handleInputChange = (text: React.SetStateAction<string>) => {
    setEmailValue(text);
  };

  const handleInputPassword = (text: React.SetStateAction<string>) => {
    setSenhaValue(text);
  };

  return (
    <LoginContainer>
      <Logo>
        <FcLogo />
      </Logo>

      <InputContainer>
        <TextLogin>Entrar</TextLogin>

        <TwoInput>
          <ContainerImputs style={{ marginBottom: 20 }}>
            <IconSpace>
              <Image source={require("../../assets/emailIcon.png")} />
            </IconSpace>
            <EraseSpace onPress={() => setEmailValue("")}>
              <Image source={require("../../assets/eraseIcon.png")} />
            </EraseSpace>
            <InputLogin
              keyboardType="email-address"
              placeholder="Digite o seu email"
              onChangeText={handleInputChange}
              value={emailValue}
              style={{
                borderWidth: 1,
                backgroundColor:
                  emailValue.length === 0
                    ? "rgb(229, 230, 230)"
                    : !validEmail.test(emailValue) && emailValue.length > 0
                    ? "#fbdde1"
                    : "#EBFCE3",
              }}
            />
          </ContainerImputs>

          {!validEmail.test(emailValue) && emailValue.length > 1 && (
            <>
              <Text style={{ marginTop: 30, color: "#b3261e" }}>
                Formato inválido, tente novamente!
              </Text>
            </>
          )}
          <ContainerImputs style={{ marginTop: 10 }}>
            <IconSpace style={{ marginLeft: 7, marginTop: -4 }}>
              <Image
                source={require("../../assets/lock.png")}
                style={{ width: 25, height: 25 }}
              />
            </IconSpace>

            <EyeSpace onPress={() => setPasswordVisible(!passwordVisible)}>
              <Image
                source={
                  passwordVisible
                    ? require("../../assets/state-layer.png")
                    : require("../../assets/trailing-icon.png")
                }
                style={{ width: 50, height: 50 }}
              />
            </EyeSpace>

            <InputLogin
              secureTextEntry={passwordVisible}
              placeholder="Digite a sua senha"
              onChangeText={handleInputPassword}
              value={senhaValue}
              selectionColor="transparent"
              underlineColorAndroid="transparent"
              style={{
                marginTop: 10,
                borderWidth: 1,
                backgroundColor:
                  senhaValue.length === 0
                    ? "rgb(229, 230, 230);"
                    : senhaValue.length < 8 && senhaValue.length > 0
                    ? "#fbdde1"
                    : "#EBFCE3"
              }}
            />
          </ContainerImputs>

          {senhaValue.length < 8 && senhaValue.length > 1 && (
            <Text
              style={{
                marginTop: 10,
                marginBottom: 10,
                color: "#b3261e",
              }}
            >
              Senha deve ter no mínimo 8 caracteres
            </Text>
          )}
        </TwoInput>

        <TextSenha>Esqueci a senha </TextSenha>
      </InputContainer>

      <ButtonContainer>
        <Button
          onPress={() => UserLogin(emailValue, senhaValue)}
          disabled={!(validEmail.test(emailValue) && senhaValue.length >= 8)}
          isActive={validEmail.test(emailValue) && senhaValue.length >= 8}
          style={{
            backgroundColor:
              validEmail.test(emailValue) && senhaValue.length >= 8
                ? "#EA374D"
                : "rgb(222, 224, 221)",
          }}
        >
          <IconSpace style={{ marginLeft: 70 }}>
            {validEmail.test(emailValue) && senhaValue.length >= 8 ? (
              <Image
                source={require("../../assets/iconEnter.png")}
                style={{ width: 25, height: 25 }}
              />
            ) : (
              <Image
                source={require("../../assets/icon.png")}
                style={{ width: 25, height: 25 }}
              />
            )}{" "}
          </IconSpace>
          Entrar
        </Button>

        <TextOuuuu>ou</TextOuuuu>
        <TextOuuuu>
          Não possui uma conta? <TextCadastro>Cadastre-se</TextCadastro>
        </TextOuuuu>
      </ButtonContainer>
    </LoginContainer>
  );
};

export { LoginScreen };
